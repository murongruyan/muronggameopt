# 注意 这不是占位符！！这个代码的作用是将模块里的东西全部塞系统里，然后挂上默认权限
SKIPUNZIP=0
#!/bin/bash
set_perm_recursive $MODPATH 0 0 0777 0777
print_modname() {
	ui_print "*******************************"
	ui_print "     	Magisk Module        "
	ui_print "Make By 慕容茹艳（酷安慕容雪绒）"
	ui_print "*******************************"
}

/system/bin/sh "/data/adb/modules_update/muronggameopt/bin/test.sh"

DIR=/data/media/0/Android/muronggameopt

echo "风驰文件来源：酷安真是卡哇伊呢"

# 执行pm enable命令
pm enable com.oplus.cosa/com.oplus.cosa.gamemanagersdk.CosaAMTService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.gamemanagersdk.HyperBoostService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.gamemanagersdk.CosaGameSdkService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.service.COSAService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.service.GameDaemonService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.gamemanagersdk.CosaHyperBoostService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.testlibrary.service.COSATesterService > /dev/null 2>&1
pm enable com.oplus.cosa/androidx.work.impl.background.systemjob.SystemJobService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.feature.ScreenPerceptionService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.gpalibrary.service.GPAService > /dev/null 2>&1
pm enable com.oplus.cosa/androidx.work.impl.background.systemalarm.SystemAlarmService > /dev/null 2>&1
pm enable com.oplus.cosa/androidx.work.impl.foreground.SystemForegroundService > /dev/null 2>&1
pm enable com.oplus.cosa/androidx.room.MultiInstanceInvalidationService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.service.GameEventService > /dev/null 2>&1
echo "* 启用应用增强组件完毕（修复环境）"
echo "* 如重启后无效果，去/data/adb/modules/murongfengchi/bin/test.sh即可 "
echo "* 需官方内核,且不禁用任何官方的组件，进程，还需要调速器有scx。（卸载请清楚应用增强数据）"
echo "* 请勿把金铲铲，王者，和平，cfm，lolm，星铁，原神，永劫无间，燕云十六声，CODM，三角洲，鸣潮放置其他模式，以防止吃不上风驰！强制等待5秒"
sleep 10
echo "       "
echo "* 本次更新日志："
echo "* 2025年3月14号02.55更新日志：
1.添加风驰内核！
2.优化service.sh脚本，优化风驰脚本，使其功耗更低。
3.添加检测前台应用替换scx，适配更多游戏！
4.增加挂载一加ACE5的vendor_dlkm/lib/modules/oplus_bsp_sched_ext.ko文件。"

# 目标目录
DIR="/storage/emulated/0/Android/muronggameopt"
VOLUME_KEY_DEVICE="/dev/input/event2"
your_module_id="muronggameopt"

# 延迟输出函数
Outputs() {
  echo "$@"
  sleep 0.07
}

# 获取应用名称
get_app_name() {
  local package_name="$1"
  local app_name=$(dumpsys package "$package_name" | grep -i 'application-label:' | cut -d':' -f2 | tr -d '[:space:]')
  if [ -z "$app_name" ]; then
    app_name="$package_name"
  fi
  echo "$app_name"
}

# 监听音量键
Volume_key_monitoring() {
  local choose
  while :; do
    choose="$(getevent -qlc 1 | awk '{ print $3 }')"
    case "$choose" in
    KEY_VOLUMEUP) echo "0" && break ;;
    KEY_VOLUMEDOWN) echo "1" && break ;;
    esac
  done
}

# 安装APK
install_apk() {
  apk_file="$1"
  if [ -f "$apk_file" ]; then
    pm install -r "$apk_file"
    echo "软件安装成功."
  else
    echo "Error: $apk_file 未找到!"
    exit 1
  fi
}

# 安装Magisk模块
install_module() {
  local zipfile="$1"
  unzip -o "$zipfile" -d "/data/adb/modules_update"
  return 0
}

# 检测冲突的Magisk模块
check_conflict_modules() {
  local conflict_module_detected=false
  for module_dir in /data/adb/modules/*; do
    if [ -d "$module_dir" ]; then
      current_module_id=$(grep -m 1 'id=' "$module_dir/module.prop" | cut -d '=' -f2)
      
      # 排除自身模块
      if [ "$current_module_id" == "$your_module_id" ]; then
        continue
      fi

      prop_file="$module_dir/system.prop"
      if [ -f "$prop_file" ] && grep -q 'persist.oplus.display.vrr' 'persist.oplus.display.vrr.adfr' 'persist.oplus.display.pixelworks' "$prop_file"; then
        conflict_module_detected=true
        module_prop="$module_dir/module.prop"
        if [ -f "$module_prop" ]; then
          conflict_module_name=$(grep -m 1 'name=' "$module_prop" | cut -d '=' -f2)
          
          Outputs "检测到冲突的Magisk模块: $conflict_module_name"
          Outputs "请问是否卸载？"
          Outputs "   - 音量上键 = 卸载模块"
          Outputs "   - 音量下键 = 取消安装"

          branch=$(Volume_key_monitoring)

          if [ "$branch" == "0" ]; then
            Outputs "正在卸载冲突模块..."
            if [ -f "$module_dir/service.sh" ]; then
              "$module_dir/service.sh" --stop
            fi
            rm -rf "$module_dir"
            if [ $? -eq 0 ]; then
              Outputs "卸载成功。"
            else
              Outputs "卸载失败，请检查权限或手动卸载。"
              exit 1
            fi
          else
            Outputs "取消安装。"
            exit 1
          fi
        fi
      fi
    fi
  done

  if [ "$conflict_module_detected" = false ]; then
    Outputs "没有检测到冲突的Magisk模块。"
  fi
}

# 更新service.sh文件
update_service_sh() {
  local service_sh="$1"
  if [ -f "$service_sh" ]; then
    local service_sh_content=$(cat "$service_sh")
    local service_sh_head=$(echo "$service_sh_content" | head -n 39)
    local service_sh_tail=$(echo "$service_sh_content" | tail -n +41)

    # 追加新的第40行命令
    local new_line="$2"
    echo -e "$service_sh_head\n$new_line\n$service_sh_tail" > "$service_sh"
    echo "已向service.sh文件写入命令。"
  else
    echo "service.sh文件不存在，无法写入命令。"
  fi
}

sh $MODPATH/vtools/init_vtools.sh $(realpath $MODPATH/module.prop)

# 主安装逻辑
main() {
  # 检测音量键设备文件
  if [ ! -e "$VOLUME_KEY_DEVICE" ]; then
    Outputs "音量键设备文件不存在，无法检测音量键事件。"
    exit 1
  fi

  # 检测冲突模块
  check_conflict_modules
  
  rm -rf "$DIR"
  mkdir -p "$DIR"

  # 确保mode.txt存在
  if [ ! -f "$DIR/mode.txt" ]; then
    echo "powersave" >"$DIR/mode.txt"
  fi

  # 提示安装APK
  echo "是否使用调度专属软件控制调度?"
  echo "   - 音量上键 = 使用apk控制"
  echo "   - 音量下键 = 使用scene控制"
  branch=$(Volume_key_monitoring)

  if [ "$branch" == "0" ]; then
    install_apk "$MODPATH/慕容官调优化.apk"
    sed -i '40i\sed -i '\''s/mode.txt/0.txt/g'\'' /data/powercfg.sh' "$service_sh_file"
    sed -i 's/mode.txt/0.txt/g' /data/powercfg.sh
  else
    echo "用户选择跳过安装APK。"
  fi
}

# 调用主安装函数
main

rm -rf $DIR/diymode.txt
# 确保diymode.txt存在
    if [ ! -f "$DIR/diymode.txt" ]; then
      touch "$DIR/diymode.txt"
      echo "com.tencent.tmgp.sgame fengchi
com.tencent.tmgp.pubgmhd fengchi
com.tencent.tmgp.cf fengchi
com.tencent.tmgp.cod fengchi
com.tencent.tmgp.dfm fengchi
com.tencent.lolm fengchi
com.netease.l22 fengchi
com.tencent.jkchess fengchi
com.miHoYo.Yuanshen fengchi
com.kurogame.mingchao fengchi
com.miHoYo.hkrpg fengchi
com.netease.yyslscn fengchi" >"$DIR/diymode.txt"
    fi
