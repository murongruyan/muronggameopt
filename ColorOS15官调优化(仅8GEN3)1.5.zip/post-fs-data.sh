MODDIR=${0%/*}
mount --bind $MODDIR/my_product/etc/refresh_rate_config.xml /my_product/etc/refresh_rate_config.xml
mount --bind $MODDIR/my_product/etc/oplus_vrr_config.json /my_product/etc/oplus_vrr_config.json

mount --bind $MODDIR/my_product/vendor/etc/display_brightness_app_list.xml /my_product/vendor/etc/display_brightness_app_list.xml
mount --bind $MODDIR/my_product/vendor/etc/display_brightness_config_P_3.xml /my_product/vendor/etc/display_brightness_config_P_3.xml
mount --bind $MODDIR/my_product/vendor/etc/multimedia_display_feature_config.xml multimedia_display_feature_config.xml
mount --bind $MODDIR/my_product/vendor/etc/multimedia_display_trackpoint_config.xml /my_product/vendor/etc/multimedia_display_trackpoint_config.xml
mount --bind $MODDIR/my_product/vendor/etc/multimedia_pixelworks_game_apps.xml /my_product/vendor/etc/multimedia_pixelworks_game_apps.xml

mount --bind $MODDIR/system/vendor/etc/perf/perfboostsconfig.xml /system/vendor/etc/perf/perfboostsconfig.xml
mount --bind $MODDIR/system/vendor/etc/perf/perfconfigstore.xml /system/vendor/etc/perf/perfconfigstore.xml

mount --bind $MODDIR/vendor_dlkm/lib/modules/oplus_bsp_sched_ext.ko vendor_dlkm/lib/modules/oplus_bsp_sched_ext.ko