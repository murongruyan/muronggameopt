# 注意 这不是占位符！！这个代码的作用是将模块里的东西全部塞系统里，然后挂上默认权限
SKIPUNZIP=0
#!/bin/bash
set_perm_recursive $MODPATH 0 0 0777 0777
print_modname() {
	ui_print "*******************************"
	ui_print "     	Magisk Module        "
	ui_print "Make By 慕容茹艳（酷安慕容雪绒）"
	ui_print "*******************************"
}

# 目标目录
DIR="/data/media/0/Android/muronggameopt"
VOLUME_KEY_DEVICE="/dev/input/event2"
your_module_id="muronggameopt"

# 延迟输出函数
Outputs() {
  echo "$@"
  sleep 0.07
}

# 获取应用名称
get_app_name() {
  local package_name="$1"
  local app_name=$(dumpsys package "$package_name" | grep -i 'application-label:' | cut -d':' -f2 | tr -d '[:space:]')
  if [ -z "$app_name" ]; then
    app_name="$package_name"
  fi
  echo "$app_name"
}

# 监听音量键
Volume_key_monitoring() {
  local choose
  while :; do
    choose="$(getevent -qlc 1 | awk '{ print $3 }')"
    case "$choose" in
    KEY_VOLUMEUP) echo "0" && break ;;
    KEY_VOLUMEDOWN) echo "1" && break ;;
    esac
  done
}

# 安装APK
install_apk() {
  apk_file="$1"
  if [ -f "$apk_file" ]; then
    pm install -r "$apk_file"
    echo "软件安装成功."
  else
    echo "Error: $apk_file 未找到!"
    exit 1
  fi
}

# 安装Magisk模块
install_module() {
  local zipfile="$1"
  unzip -o "$zipfile" -d "/data/adb/modules_update"
  return 0
}

# 检测冲突的Magisk模块
check_conflict_modules() {
  local conflict_module_detected=false
  for module_dir in /data/adb/modules/*; do
    if [ -d "$module_dir" ]; then
      current_module_id=$(grep -m 1 'id=' "$module_dir/module.prop" | cut -d '=' -f2)
      
      # 排除自身模块
      if [ "$current_module_id" == "$your_module_id" ]; then
        continue
      fi

      prop_file="$module_dir/system.prop"
      if [ -f "$prop_file" ] && grep -q 'persist.oplus.display.vrr' 'persist.oplus.display.vrr.adfr' 'persist.oplus.display.pixelworks' "$prop_file"; then
        conflict_module_detected=true
        module_prop="$module_dir/module.prop"
        if [ -f "$module_prop" ]; then
          conflict_module_name=$(grep -m 1 'name=' "$module_prop" | cut -d '=' -f2)
          
          Outputs "检测到冲突的Magisk模块: $conflict_module_name"
          Outputs "请问是否卸载？"
          Outputs "   - 音量上键 = 卸载模块"
          Outputs "   - 音量下键 = 取消安装"

          branch=$(Volume_key_monitoring)

          if [ "$branch" == "0" ]; then
            Outputs "正在卸载冲突模块..."
            if [ -f "$module_dir/service.sh" ]; then
              "$module_dir/service.sh" --stop
            fi
            rm -rf "$module_dir"
            if [ $? -eq 0 ]; then
              Outputs "卸载成功。"
            else
              Outputs "卸载失败，请检查权限或手动卸载。"
              exit 1
            fi
          else
            Outputs "取消安装。"
            exit 1
          fi
        fi
      fi
    fi
  done

  if [ "$conflict_module_detected" = false ]; then
    Outputs "没有检测到冲突的Magisk模块。"
  fi
}

# 更新service.sh文件
update_service_sh() {
  local service_sh="$1"
  if [ -f "$service_sh" ]; then
    local service_sh_content=$(cat "$service_sh")
    local service_sh_head=$(echo "$service_sh_content" | head -n 39)
    local service_sh_tail=$(echo "$service_sh_content" | tail -n +41)

    # 追加新的第40行命令
    local new_line="$2"
    echo -e "$service_sh_head\n$new_line\n$service_sh_tail" > "$service_sh"
    echo "已向service.sh文件写入命令。"
  else
    echo "service.sh文件不存在，无法写入命令。"
  fi
}

sh $MODPATH/vtools/init_vtools.sh $(realpath $MODPATH/module.prop)

# 主安装逻辑
main() {
  # 检测音量键设备文件
  if [ ! -e "$VOLUME_KEY_DEVICE" ]; then
    Outputs "音量键设备文件不存在，无法检测音量键事件。"
    exit 1
  fi

  # 检测冲突模块
  check_conflict_modules
  
  mkdir -p "$DIR"

  # 确保mode.txt存在
  if [ ! -f "$DIR/mode.txt" ]; then
    echo "powersave" >"$DIR/mode.txt"
  fi

  # 提示安装APK
  echo "是否使用调度专属软件控制调度?"
  echo "   - 音量上键 = 使用apk控制"
  echo "   - 音量下键 = 使用scene控制"
  branch=$(Volume_key_monitoring)

  if [ "$branch" == "0" ]; then
    install_apk "$MODPATH/慕容调度.apk"
    sed -i '40i\sed -i '\''s/mode.txt/0.txt/g'\'' /data/powercfg.sh' "$service_sh_file"
    sed -i 's/mode.txt/0.txt/g' /data/powercfg.sh
    # 确保diymode.txt存在
    if [ ! -f "$DIR/diymode.txt" ]; then
      touch "$DIR/diymode.txt"
      echo "com.netease.l22 balance
com.tencent.lolm balance
com.tencent.tmgp.sgame balance
com.tencent.tmgp.cod performance
com.tencent.tmgp.dfm performance
com.tencent.tmgp.pubgmhd performance
com.netease.yyslscn fast
com.miHoYo.hkrpg fast
com.tencent.tmgp.cf fast
com.miHoYo.Yuanshen fast" >"$DIR/diymode.txt"
    fi
  else
    echo "用户选择跳过安装APK。"
    rm -rf $DIR/diymode.txt
  fi
}

# 调用主安装函数
main

diy=/sdcard/Android/muronggameopt/
DIYCORE_FILE="$diy/diycore.txt"

# 检查配置文件是否存在，如果存在则备份
if [ -f "$DIYCORE_FILE" ]; then
    # 使用引号将整个文件名包括时间戳括起来，并确保备份目录存在
    bak_file="$DIYCORE_FILE.bak_$(date '+%Y-%m-%d_%H-%M-%S')"
    cp "$DIYCORE_FILE" "$bak_file" || { echo "备份失败"; exit 1; }
fi

	# 创建并写入diycore.txt
	echo "# 自定义游戏线程核心放置
# 启用修改：status=1
# 关闭修改：status=0
# 示例：以下示例请勿操作修改
#com.murongdiaodu {   # 包名 {
#status=1             # 启用1 关闭0
#app=0-7              # app进程放置0,1,2,3,4,5,6,7核心
#UnityMain*=7          # UnityMain*线程放置7核心
#UnityGfx*=2-4         # UnityGfx*线程放置2,3,4核心
#Thread-*=4-6          # Thread-*线程放置4,5,6核心
#CoreThread*=2-6       # CoreThread*线程放置2,3,4,5,6核心
#UnityPreload*=6       # UnityPreload*线程放置6核心
#Worker Thread*=2-7    # Worker Thread*线程放置2,3,4,5,6,7核心
#Apollo-*=3            # Apollo-*线程放置3核心
#Thread-*=2-3,5-6          # Thread-*线程放置2,3,5,6核心
#Thread-[5-9]=7
#Thread-1[0-5]=7      # 表示Thread-0到Thread-15内都放置7核心
#other=0-6            # 除此之外其它线程放置0,1,2,3,4,5,6核心
}                    # }  结束
# 示例：以上示例请勿操作修改
# 部分游戏具体使用线程请使用Scene浏览

# *星号表示通配符，意思为模糊搜索
# [0-9]表示范围搜索，需准确填写前面的线程名，只留后面数字，范围搜索仅支持个位数。

#执行顺序：1.精确匹配 → 2. 范围搜索 → 3. 模糊搜索


# 王者荣耀
com.tencent.tmgp.sgame {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-4
Audio*=0-7
other=2-4
}

# 原神
com.miHoYo.Yuanshen {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-4
Audio*=0-7
other=2-4
}

# 星穹铁道
com.miHoYo.hkrpg {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 和平精英
com.tencent.tmgp.pubgmhd {
status=1
app=0-7
Thread-[0-9]=7
Thread-1[0-5]=7
RenderThread*=2-6
RHIThread*=2-4
Audio*=0-7
other=2-6
}

# 英雄联盟
com.tencent.lolm {
status=1
app=0-7
UnityMain*=7
LogicThread*=5-6
Thread-*=2-6
Audio*=0-7
other=2-4
}

# QQ飞车
com.tencent.tmgp.speedmobile {
status=1
app=0-7
UnityMain*=7
Job.Worker*=2-4,7
Thread-*=2-4
Audio*=0-7
other=2-6
}

# 穿越火线：枪战王者
com.tencent.tmgp.cf {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 永劫无间手游
com.netease.l22 {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 守塔不能停
com.jwestern.m4d {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 炉石传说国际服
com.hearthstone {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 阴阳师
com.netease.onmyoji {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 崩坏3
com.miHoYo.bh3.uc {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 崩坏3
com.miHoYo.bh3.mi {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 崩坏3
com.miHoYo.enterprise.NGHSoD {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 崩坏3
com.miHoYo.bh3.bilibili {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 明日方舟
com.hypergryph.arknights {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 星球重启
com.hermes.j1game.mi {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 星球重启
com.hermes.j1game {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 星球重启
com.hermes.j1game.aligames {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 星球重启
com.hermes.j1game.huawei {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 星球重启
com.hermes.j1game.vivo {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 地下城与勇士手游
com.tencent.tmgp.dnf {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 逆水寒手游
com.netease.nshm {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 学园偶像大师
com.bandainamcoent.idolmaster_gakuen {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 猎魂觉醒网易
com.netease.AVALON {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 深空之眼
com.yongshi.tenojo.ys {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 部落冲突
com.tencent.tmgp.supercell.clashofclans {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 海岛奇兵国际服
com.supercell.boombeach {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 幻塔
com.pwrd.hotta.laohu {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 火影忍者
com.tencent.KiHan {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 金铲铲之战
com.tencent.jkchess {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 使命召唤手游
com.tencent.tmgp.cod {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 碧蓝航线
com.bilibili.azurlane {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 战双帕弥什
com.kurogame.haru.aligames {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 战双帕弥什
com.kurogame.haru.hero {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 来自星尘
com.hypergryph.exastris {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 重返未来1999
com.shenlan.m.reverse1999 {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 蛋仔派对
com.netease.party.nearme.gamecenter {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 蛋仔派对
com.netease.party {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 元梦之星
com.tencent.letsgo {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# NBA 2K20
com.t2ksports.nba2k20and {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 王牌竞速
com.netease.aceracer.aligames {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 香肠派对
com.sofunny.Sausage {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 迷你世界
com.playmini.miniworld {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 尘白禁区
com.dragonli.projectsnow.lhm {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 绝区零
com.miHoYo.Nap {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 使命召唤:战争地带
com.activision.callofduty.warzone {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-3
Thread-*=5-6
Job.Worker*=4
Audio*=0-7
RenderThread*=2-6
RHIThread*=2-4
MainThread*=2-4,7
GameThread*=7
other=2-3,5-6
}

# YGOPro3
com.YGO.MDPro3 {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-4
Thread-*=2-6
Job.Worker*=2-6
Audio*=0-7
other=2-4
}

# 和平精英日韩服
com.pubg.krmobile {
status=1
app=0-7
Thread-*=7
RenderThread*=2-6
RHIThread*=2-4
Audio*=0-7
other=2-6
}

# 和平精英国际服
com.tencent.ig {
status=1
app=0-7
Thread-*=7
RenderThread*=2-6
RHIThread*=2-4
Audio*=0-7
other=2-6
}

# 鸣潮
com.kurogame.mingchao {
status=1
app=0-7
Thread-*=7
RenderThread*=2-6
RHIThread*=2-4
MainThread*=2-4,7
GameThread*=7
Audio*=0-7
other=2-6
}

# 晶核
com.hermes.p6game {
status=1
app=0-7
Thread-*=7
RenderThread*=2-6
RHIThread*=2-4
MainThread*=2-4,7
GameThread*=7
Audio*=0-7
other=2-6
}

# 晶核
com.hermes.p6game.aligames {
status=1
app=0-7
Thread-*=7
RenderThread*=2-6
RHIThread*=2-4
MainThread*=2-4,7
GameThread*=7
Audio*=0-7
other=2-6
}

# 晶核
com.hermes.p6game.huawei {
status=1
app=0-7
Thread-*=7
RenderThread*=2-6
RHIThread*=2-4
MainThread*=2-4,7
GameThread*=7
Audio*=0-7
other=2-6
}

# 暗区突围
com.tencent.mf.uam {
status=1
app=0-7
Thread-*=7
RenderThread*=2-6
RHIThread*=2-4
MainThread*=2-4,7
GameThread*=7
Audio*=0-7
other=2-6
}

# 巅峰极速
com.netease.race {
status=1
app=0-7
Thread-*=7
RenderThread*=2-6
RHIThread*=2-4
MainThread*=2-4,7
GameThread*=7
Audio*=0-7
other=2-6
}

# 荒野行动
com.netease.hyxd.nearme.gamecenter {
status=1
app=0-7
Thread-*=7
RenderThread*=2-6
RHIThread*=2-4
MainThread*=2-4,7
GameThread*=7
Audio*=0-7
other=2-6
}

# 荒野行动
com.netease.hyxd.aligames {
status=1
app=0-7
Thread-*=7
RenderThread*=2-6
RHIThread*=2-4
MainThread*=2-4,7
GameThread*=7
Audio*=0-7
other=2-6
}

# 三角洲行动
com.tencent.tmgp.dfm {
status=1
app=0-7
Thread-*=7
RenderThread*=2-6
RHIThread*=2-4
MainThread*=2-4,7
GameThread*=7
Audio*=0-7
other=2-6
}

# 极品飞车:集结
com.tencent.nfsonline {
status=1
app=0-7
UnityMain*=7
UnityGfx*=2-3
Thread-*=5-6
Job.Worker*=4
Audio*=0-7
RenderThread*=2-6
RHIThread*=2-4
MainThread*=2-4,7
GameThread*=7
other=2-3,5-6
}

# 燕云十六声
com.netease.yyslscn {
status=1
app=0-7
Thread-*=7
RenderThread*=2-6
RHIThread*=2-4
MainThread*=2-4,7
GameThread*=7
Audio*=0-7
other=2-6
}

" >"$DIYCORE_FILE"