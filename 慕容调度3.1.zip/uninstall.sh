#!/system/bin/sh
TeamS=${0%/*}
# 删除脚本
rm -rf /data/media/0/Android/muronggameopt
rm -rf /data/powercfg.json
rm -rf /data/powercfg.sh