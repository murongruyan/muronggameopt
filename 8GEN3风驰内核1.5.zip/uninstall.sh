#!/system/bin/sh
TeamS=${0%/*}
# 删除脚本
pm clear com.oplus.cosa