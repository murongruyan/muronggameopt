MODDIR=${0%/*}

mount --bind $MODDIR/vendor_dlkm/lib/modules/oplus_bsp_sched_ext.ko vendor_dlkm/lib/modules/oplus_bsp_sched_ext.ko