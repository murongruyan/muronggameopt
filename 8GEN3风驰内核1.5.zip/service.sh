#!/system/bin/sh
TeamS=${0%/*}
chmod -R 755 "$TeamS"

# in case of /data encryption is disabled
While() {
	[ "$(getprop sys.boot_completed)" != 1 ] && {
		sleep 30s
		While
	}
}

echo 1 > /proc/sys/walt/sched_conservative_pl

{
	#Use system interpreter
	/system/bin/sh "$TeamS/activity_diaodu.rc" &
	#Leave the process
    exit 0
}