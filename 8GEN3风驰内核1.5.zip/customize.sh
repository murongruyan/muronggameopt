# 注意 这不是占位符！！这个代码的作用是将模块里的东西全部塞系统里，然后挂上默认权限
SKIPUNZIP=0
#!/bin/bash
set_perm_recursive $MODPATH 0 0 0777 0777
print_modname() {
	ui_print "*******************************"
	ui_print "     	Magisk Module        "
	ui_print "Make By 慕容茹艳（酷安慕容雪绒）"
	ui_print "*******************************"
}

/system/bin/sh "/data/adb/modules_update/murongfengchi/bin/test.sh"

echo "文件来源：酷安真是卡哇伊呢"

# 执行pm enable命令
pm enable com.oplus.cosa/com.oplus.cosa.gamemanagersdk.CosaAMTService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.gamemanagersdk.HyperBoostService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.gamemanagersdk.CosaGameSdkService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.service.COSAService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.service.GameDaemonService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.gamemanagersdk.CosaHyperBoostService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.testlibrary.service.COSATesterService > /dev/null 2>&1
pm enable com.oplus.cosa/androidx.work.impl.background.systemjob.SystemJobService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.feature.ScreenPerceptionService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.gpalibrary.service.GPAService > /dev/null 2>&1
pm enable com.oplus.cosa/androidx.work.impl.background.systemalarm.SystemAlarmService > /dev/null 2>&1
pm enable com.oplus.cosa/androidx.work.impl.foreground.SystemForegroundService > /dev/null 2>&1
pm enable com.oplus.cosa/androidx.room.MultiInstanceInvalidationService > /dev/null 2>&1
pm enable com.oplus.cosa/com.oplus.cosa.service.GameEventService > /dev/null 2>&1
echo "* 启用应用增强组件完毕（修复环境）"
echo "* 如重启后无效果，去/data/adb/modules/murongfengchi/bin/test.sh即可 "
echo "* 需官方内核,且不禁用任何官方的组件，进程，还需要调速器有scx。（卸载请清楚应用增强数据）"
echo "       "
echo "* 本次更新日志："
echo "* 2025年3月14号02.55更新日志：
1.优化service.sh脚本，优化风驰脚本，使其功耗更低。
2.添加检测前台应用替换scx，使其支持更多应用！
3.增加挂载一加ACE5的vendor_dlkm/lib/modules/oplus_bsp_sched_ext.ko文件。"